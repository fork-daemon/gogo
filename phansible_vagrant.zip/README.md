
# install soft
 - virtual box (latest)
 - vagrant (latest)

# install

    add to your hosts file:

    > 192.168.33.99   elasticsearch.dev   www.elasticsearch.dev

# Work

    Start (setup) virtual machine:
    bash > cd [project-dir] && vagrant up

    Stop virtual machine:
    bash > cd [project-dir] && vagrant halt

    Change provision (if somebody edit vagrants/ansible files):
    bash > cd [project-dir] && vagrant provision

    Enter virtual machine over ssh:
    bash > cd [project-dir] && vagrant ssh

    OR in PHPStorm you can use "MENU > Tools > Vagrant"


